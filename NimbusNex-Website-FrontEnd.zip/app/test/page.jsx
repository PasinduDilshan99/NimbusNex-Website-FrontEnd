import React from "react";
import SearchIcon from "@mui/icons-material/Search";

const page = () => {
  return (
    <div className="flex min-h-[100vh] items-center text-center justify-center">
      <div className="btn1">abc</div>
    </div>
  );
};

export default page;
