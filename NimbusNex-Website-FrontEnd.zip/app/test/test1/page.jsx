import Carousel from "@/app/components/Carosuel";
import React from "react";

const page = () => {
  return (
    <div className="relative">
      <Carousel />
      <p className="aa">ABCDEF GHIJK</p>

    </div>
  );
};

export default page;
